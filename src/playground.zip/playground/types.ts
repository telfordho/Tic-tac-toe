export type Puzzle = string | null;
export type MatchMap = {
  [rowNumber: string]: Puzzle[],
}