export const Circle: React.FC = () => {
  return <div className="circle">O</div>;
};
