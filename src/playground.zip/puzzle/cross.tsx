export const Cross: React.FC = () => {
  return <div className="cross">X</div>;
};
